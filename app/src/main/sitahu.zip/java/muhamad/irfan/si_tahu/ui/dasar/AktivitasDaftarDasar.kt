package muhamad.irfan.si_tahu.ui.dasar

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import muhamad.irfan.si_tahu.databinding.ActivityListScreenBinding
import muhamad.irfan.si_tahu.ui.umum.AdapterBarisUmum
import muhamad.irfan.si_tahu.ui.utama.PendengarPilihItemSederhana
import muhamad.irfan.si_tahu.util.AdapterSpinner
import muhamad.irfan.si_tahu.util.ItemBaris

abstract class AktivitasDaftarDasar : AktivitasDasar() {

    protected lateinit var binding: ActivityListScreenBinding
    protected lateinit var rowAdapter: AdapterBarisUmum

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        rowAdapter = AdapterBarisUmum(
            onItemClick = ::onRowClick,
            onActionClick = ::onRowAction,
            onEditClick = ::onRowEdit,
            onDeleteClick = ::onRowDelete
        )

        rowAdapter.submitList(emptyList())
        binding.rvList.layoutManager = LinearLayoutManager(this)
        binding.rvList.adapter = rowAdapter

        binding.etSearch.addTextChangedListener {
            onSearchChanged()
        }

        binding.buttonRow.isVisible = false
        binding.fabAdd.isVisible = false
        binding.paginationContainer.isVisible = false
        binding.tvEmpty.isVisible = false
        binding.btnOpenFilters.isVisible = false
        binding.tvFilterBadge.isVisible = false
        binding.cardProductSelector.isVisible = false
    }

    protected fun configureScreen(
        title: String,
        subtitle: String? = null,
        searchHint: String = "Cari data...",
        showBack: Boolean = true
    ) {
        bindToolbar(binding.toolbar, title, subtitle, showBack)
        binding.etSearch.hint = searchHint
    }

    protected fun setPrimaryFilter(
        options: List<String>,
        selectedIndex: Int = 0,
        onChange: () -> Unit
    ) {
        binding.cardPrimaryFilter.isVisible = true
        binding.spPrimaryFilter.isVisible = true
        binding.spPrimaryFilter.adapter = AdapterSpinner.stringAdapter(this, options)
        binding.spPrimaryFilter.setSelection(selectedIndex)
        binding.spPrimaryFilter.onItemSelectedListener = PendengarPilihItemSederhana(onChange)
    }

    protected fun setProductSelector(
        label: String,
        productName: String,
        productInfo: String,
        listener: View.OnClickListener
    ) {
        binding.cardProductSelector.isVisible = true
        binding.tvProductSelectorLabel.text = label
        binding.tvSelectedProductName.text = productName.ifBlank { "Pilih produk" }
        binding.tvSelectedProductInfo.text = productInfo.ifBlank { "Cari dan pilih produk yang ingin diatur" }
        binding.tvProductSelectorLeading.text = productName.firstOrNull()?.uppercaseChar()?.toString() ?: "P"
        binding.cardProductSelector.setOnClickListener(listener)
    }

    protected fun hideProductSelector() {
        binding.cardProductSelector.isVisible = false
    }

    protected fun setSecondaryFilter(
        options: List<String>,
        selectedIndex: Int = 0,
        onChange: () -> Unit
    ) {
        binding.cardSecondaryFilter.isVisible = true
        binding.spSecondaryFilter.adapter = AdapterSpinner.stringAdapter(this, options)
        binding.spSecondaryFilter.setSelection(selectedIndex)
        binding.spSecondaryFilter.onItemSelectedListener = PendengarPilihItemSederhana(onChange)
    }

    protected fun showFilterButton(onClick: View.OnClickListener) {
        binding.btnOpenFilters.isVisible = true
        binding.btnOpenFilters.setOnClickListener(onClick)
    }

    protected fun hideFilterButton() {
        binding.btnOpenFilters.isVisible = false
        binding.tvFilterBadge.isVisible = false
        binding.cardProductSelector.isVisible = false
    }

    protected fun setFilterBadge(count: Int) {
        binding.tvFilterBadge.isVisible = count > 0
        binding.tvFilterBadge.text = if (count > 9) "9+" else count.toString()
    }

    protected fun hideSearch() {
        binding.searchContainer.isVisible = false
        binding.btnOpenFilters.isVisible = false
        binding.tvFilterBadge.isVisible = false
        binding.cardProductSelector.isVisible = false
    }

    protected fun hidePrimaryFilter() {
        binding.cardPrimaryFilter.isVisible = false
        binding.spPrimaryFilter.isVisible = false
    }

    protected fun hideSecondaryFilter() {
        binding.cardSecondaryFilter.isVisible = false
    }

    protected fun setPrimaryButton(label: String, listener: View.OnClickListener) {
        binding.btnPrimary.isVisible = true
        binding.btnPrimary.text = label
        binding.btnPrimary.setOnClickListener(listener)
        binding.buttonRow.isVisible = true
    }

    protected fun setSecondaryButton(label: String, listener: View.OnClickListener) {
        binding.btnSecondary.isVisible = true
        binding.btnSecondary.text = label
        binding.btnSecondary.setOnClickListener(listener)
        binding.buttonRow.isVisible = true
    }

    protected fun hidePrimaryButton() {
        binding.btnPrimary.isVisible = false
        binding.buttonRow.isVisible = binding.btnSecondary.isVisible
    }

    protected fun hideSecondaryButton() {
        binding.btnSecondary.isVisible = false
        binding.buttonRow.isVisible = binding.btnPrimary.isVisible
    }

    protected fun hideButtons() {
        binding.buttonRow.isVisible = false
    }

    protected fun showPagination(
        currentPage: Int,
        totalPages: Int,
        onPrev: (() -> Unit)?,
        onNext: (() -> Unit)?
    ) {
        binding.paginationContainer.isVisible = totalPages > 1
        binding.tvPageInfo.text = "Halaman $currentPage dari $totalPages"

        binding.btnPagePrev.isEnabled = onPrev != null
        binding.btnPagePrev.alpha = if (onPrev != null) 1f else 0.45f
        binding.btnPagePrev.setOnClickListener { onPrev?.invoke() }

        binding.btnPageNext.isEnabled = onNext != null
        binding.btnPageNext.alpha = if (onNext != null) 1f else 0.45f
        binding.btnPageNext.setOnClickListener { onNext?.invoke() }
    }

    protected fun hidePagination() {
        binding.paginationContainer.isVisible = false
    }

    protected fun searchText(): String {
        return binding.etSearch.text?.toString().orEmpty().trim().lowercase()
    }

    protected fun primarySelection(): String {
        return binding.spPrimaryFilter.selectedItem?.toString().orEmpty()
    }

    protected fun secondarySelection(): String {
        return binding.spSecondaryFilter.selectedItem?.toString().orEmpty()
    }

    protected fun submitRows(rows: List<ItemBaris>, emptyMessage: String = "Belum ada data") {
        rowAdapter.submitList(rows)
        binding.tvEmpty.isVisible = rows.isEmpty()
        binding.tvEmpty.text = emptyMessage
        binding.rvList.isVisible = rows.isNotEmpty()
    }

    protected fun setFabAdd(listener: View.OnClickListener) {
        binding.fabAdd.isVisible = true
        binding.fabAdd.setOnClickListener(listener)
    }

    protected fun hideFabAdd() {
        binding.fabAdd.isVisible = false
    }

    protected open fun onRowEdit(item: ItemBaris, anchor: View) = Unit
    protected open fun onSearchChanged() = Unit
    protected open fun onRowAction(item: ItemBaris, anchor: View) = Unit
    protected open fun onRowDelete(item: ItemBaris) = Unit
    protected abstract fun onRowClick(item: ItemBaris)
}
