package muhamad.irfan.si_tahu.util

import android.content.Context
import android.graphics.Typeface
import android.text.method.LinkMovementMethod
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object PembantuModal {
    fun showDetailModal(
        context: Context,
        title: String,
        message: String,
        positiveLabel: String = "Tutup",
        neutralLabel: String? = null,
        onNeutral: (() -> Unit)? = null,
        negativeLabel: String? = null,
        onNegative: (() -> Unit)? = null,
        monospace: Boolean = true,
        onClosed: (() -> Unit)? = null
    ): AlertDialog {
        val density = context.resources.displayMetrics.density
        val textView = TextView(context).apply {
            text = message
            textSize = 14f
            setLineSpacing(0f, 1.35f)
            setPadding(
                (20 * density).toInt(),
                (18 * density).toInt(),
                (20 * density).toInt(),
                (18 * density).toInt()
            )
            setTextColor(context.getColorCompat(muhamad.irfan.si_tahu.R.color.text_primary))
            typeface = if (monospace) Typeface.MONOSPACE else Typeface.SANS_SERIF
            movementMethod = LinkMovementMethod.getInstance()
            setTextIsSelectable(true)
        }

        val scroll = ScrollView(context).apply { addView(textView) }

        val dialog = MaterialAlertDialogBuilder(context)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton(positiveLabel, null)
            .apply {
                if (neutralLabel != null) {
                    setNeutralButton(neutralLabel) { _, _ -> onNeutral?.invoke() }
                }
                if (negativeLabel != null) {
                    setNegativeButton(negativeLabel) { _, _ -> onNegative?.invoke() }
                }
            }
            .show()

        dialog.setOnDismissListener {
            onClosed?.invoke()
        }

        return dialog
    }

    fun showInputModal(
        context: Context,
        title: String,
        hint: String,
        confirmLabel: String = "Simpan",
        initialValue: String = "",
        onConfirm: (String) -> Unit
    ): AlertDialog {
        val density = context.resources.displayMetrics.density
        val inputLayout = TextInputLayout(context).apply {
            setPadding((20 * density).toInt(), (8 * density).toInt(), (20 * density).toInt(), 0)
        }
        val input = TextInputEditText(context).apply {
            setText(initialValue)
            setHint(hint)
            maxLines = 4
            minLines = 3
        }
        inputLayout.addView(input)

        val dialog = MaterialAlertDialogBuilder(context)
            .setTitle(title)
            .setView(inputLayout)
            .setNegativeButton("Tutup", null)
            .setPositiveButton(confirmLabel, null)
            .show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val value = input.text?.toString()?.trim().orEmpty()
            if (value.isBlank()) {
                inputLayout.error = "$hint wajib diisi"
            } else {
                inputLayout.error = null
                onConfirm(value)
                dialog.dismiss()
            }
        }
        return dialog
    }

    fun showConfirmationModal(
        context: Context,
        title: String,
        message: String,
        confirmLabel: String = "Hapus",
        onConfirm: () -> Unit,
        cancelLabel: String = "Batal"
    ): AlertDialog {
        return MaterialAlertDialogBuilder(context)
            .setTitle(title)
            .setMessage(message)
            .setNegativeButton(cancelLabel, null)
            .setPositiveButton(confirmLabel) { _, _ -> onConfirm() }
            .show()
    }

    private fun Context.getColorCompat(colorRes: Int): Int =
        androidx.core.content.ContextCompat.getColor(this, colorRes)
}