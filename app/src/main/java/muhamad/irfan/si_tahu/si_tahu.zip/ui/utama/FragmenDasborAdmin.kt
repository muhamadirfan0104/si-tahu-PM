// FragmenDasborAdmin.kt
package muhamad.irfan.si_tahu.ui.utama

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import muhamad.irfan.si_tahu.R
import muhamad.irfan.si_tahu.databinding.FragmentAdminDashboardBinding
import muhamad.irfan.si_tahu.ui.dasar.FragmenDasar
import muhamad.irfan.si_tahu.ui.umum.AdapterBarisUmum

class FragmenDasborAdmin : FragmenDasar(R.layout.fragment_admin_dashboard) {
    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    private val lowStockAdapter = AdapterBarisUmum(onItemClick = {})
    private val recentAdapter = AdapterBarisUmum(onItemClick = {})

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (!requireLoginOrRedirect()) return

        _binding = FragmentAdminDashboardBinding.bind(view)

        binding.rvLowStock.layoutManager = LinearLayoutManager(requireContext())
        binding.rvLowStock.adapter = lowStockAdapter
        binding.rvRecentTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRecentTransactions.adapter = recentAdapter

        binding.btnGoProduction.visibility = View.GONE
        binding.btnGoSales.visibility = View.GONE
        binding.btnGoStock.visibility = View.GONE
        binding.btnNewExpense.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        renderEmptyState()
    }

    private fun renderEmptyState() {
        binding.tvSummaryDate.text = "Ringkasan belum terhubung"
        binding.tvSummarySales.text = "-"
        binding.tvSummaryProduction.text = "Produksi: -"
        binding.tvSummaryExpenses.text = "Pengeluaran: -"
        binding.tvSummaryTransactions.text = "Transaksi: -"
        binding.tvSummaryProfit.text = "Laba sementara: -"

        lowStockAdapter.submitList(emptyList())
        recentAdapter.submitList(emptyList())
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}